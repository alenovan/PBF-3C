const domainPath = `http://localhost:3002/`;
export default domainPath;
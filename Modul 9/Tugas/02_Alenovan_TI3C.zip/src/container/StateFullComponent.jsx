import React from 'react';

class StateFullComponent extends React.Component {
    render() {
        return <p>ini adalah Statefull Component</p>
    }
}

export default StateFullComponent;
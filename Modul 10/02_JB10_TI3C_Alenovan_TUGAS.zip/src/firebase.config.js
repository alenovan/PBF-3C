{/* <script src="https://www.gstatic.com/firebasejs/7.14.1/firebase-app.js"></script>

<script src="https://www.gstatic.com/firebasejs/7.14.1/firebase-analytics.js"></script> */}

  export default  {
    apiKey: "AIzaSyDj4iLohn3D1US79bk7Sc-PIb5b1c2g4hk",
    authDomain: "tugaskampus1-16cd5.firebaseapp.com",
    databaseURL: "https://tugaskampus1-16cd5.firebaseio.com",
    projectId: "tugaskampus1-16cd5",
    storageBucket: "tugaskampus1-16cd5.appspot.com",
    messagingSenderId: "869186910796",
    appId: "1:869186910796:web:011c5b534c1894498f92e9",
    measurementId: "G-3FN27WPPEZ"
  };
//   firebase.initializeApp(firebaseConfig);
//   firebase.analytics();
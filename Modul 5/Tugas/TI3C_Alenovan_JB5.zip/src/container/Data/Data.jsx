import React, { Component } from "react";
class Data extends Component {
    render() {
        return (
            <div class="w3-container" style={{ marginTop: "80px" }} id="showcase">
                <h2>{this.props.name}</h2>
            </div>
        )
    }
}






export default Data;